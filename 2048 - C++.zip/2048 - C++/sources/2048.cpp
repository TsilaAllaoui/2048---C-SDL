#include <SDL/SDL.h>
#include "/2048 - C++/headers/2048.h"
#include "/2048 - C++/headers/grid.h"

_2048_::_2048_()
{
    SDL_Init(SDL_INIT_EVERYTHING);
	ecran = SDL_SetVideoMode(33*n, 33*n, 32, SDL_SWSURFACE | SDL_DOUBLEBUF);
	Mix_OpenAudio(22050,MIX_DEFAULT_FORMAT,2,4096);
	srand(time(0));
}

void _2048_::begin()
{
    SDL_Surface *start_screen[4];
	start_screen[0] = IMG_Load("./data/image/start_screen.png");
	start_screen[1] = IMG_Load("./data/image/start_screen_1.png");
	start_screen[2] = IMG_Load("./data/image/start_screen_2.png");
	start_screen[3] = IMG_Load("./data/image/start_screen_3.png");
	SDL_Event begin;
	bool pass = false;
	int current_stat_screen = 0;
	while (!pass)
	{
		SDL_PollEvent(&begin);
		switch (begin.type)
		{
		case SDL_KEYDOWN:
			switch (begin.key.keysym.sym)
			{
			case SDLK_SPACE:
				pass = true;
				break;
			}
		}
		SDL_BlitSurface(start_screen[current_stat_screen], NULL, ecran, NULL);
		SDL_Flip(ecran);
		SDL_Delay(500);
		if (current_stat_screen < 3)
		++current_stat_screen;
		else if (current_stat_screen == 3)
			current_stat_screen = 0;
	}
}

void _2048_::run()
{
    Grid grid(ecran);
    bool do_again = true;
	while (do_again)
	{
		begin();
		grid.generate();
		grid.update();
	    end();
	    grid.reset_tab();
	    grid.reset_tmp();
	    grid.reset_buff();
	}
}

void _2048_::end()
{
    SDL_Rect pos_end;
	pos_end.x = 32;
	pos_end.y = 32;
	SDL_Event ending;
	SDL_BlitSurface(IMG_Load("./data/image/end.png"), NULL, ecran, &pos_end);
	SDL_Flip(ecran);
	bool loop = true;
	while (loop)
	{
		SDL_WaitEvent(&ending);
		switch (ending.type)
		{
		case SDL_KEYDOWN:
			switch (ending.key.keysym.sym)
			{
			case SDLK_SPACE:
				loop = false;
				break;
			case SDLK_ESCAPE:
				exit(EXIT_SUCCESS);
				break;
			}
		}
	}
}
