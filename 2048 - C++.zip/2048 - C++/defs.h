#ifndef DEFS_H
#define DEFS_H

#include <vector>
#define n 4
#define BLOC 32
#define frame 5

#endif
