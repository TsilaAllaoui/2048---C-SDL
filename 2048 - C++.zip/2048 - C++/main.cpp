/* 2048 - CPP By TsilaAllaoui */
/*19 Mars 2020 */
/*version 1.2*/




#include <SDL/SDL.h>
#include "headers/2048.h"

int main(int argc,char **argv)
{
    _2048_().run();
    return 0;
}


/*Changelog:
     -May 2019: First Commit in C without SDL
     -September 2019: Added SDL Layer
    -19 March 2020: Remade entirely in C++ and added some animation
    -20 March 2020: fixed crash when gameover*/
      
