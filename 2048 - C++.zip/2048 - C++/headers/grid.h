#ifndef GRID_H
#define GRID_H

#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>
#include <ctime>
#include <vector>
#include "/2048 - C++/headers/defs.h"
#include "/2048 - C++/headers/fonctions.h"

using namespace std;

class Grid
{
	private:
		SDL_Surface *ecran;
	    vector < vector <int> > tab;
	    vector < vector <int> > tmp,buff;
	   SDL_Surface *tile2, *tile4, *tile8, *tile16, *tile32, *tile64, *tile128, *tile0,*tile256,*tile512,*tile1024,*tile2048;
	   Mix_Chunk *grow, *move;
	public:
	    Grid(SDL_Surface *ecran);
	    void reset_tab();
	    void reset_tmp();
	    void reset_buff();
	    void generate();
	    void update();
	    void show();
	    bool check_end();
	    bool check_gameover();
	    void transpose();
	    void add_number();
	    void set_tmp();
	    void set_buff();
	    void haut();
	    void bas();
	    void gauche();
	    void droite();
	    void draw_up(int i,int j);
	    void draw_down(int i,int j);
	    void draw_left(int i,int j);
	    void draw_right(int i,int j);
	    vector < vector <int> > get_buff();
	    SDL_Surface *set(int i,int j);
};

#endif
