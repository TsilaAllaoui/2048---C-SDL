#include "grid.h"
#include "fonctions.h"
#include <vector>

using namespace std;

Grid::Grid(SDL_Surface * screen)
{
	ecran = screen;
	for (int i = 0; i < n; i++)
	{
		tab.push_back(vector < int >(n));
		tmp.push_back(vector < int >(n));
		buff.push_back(vector < int >(n));
	}
	tile2 = IMG_Load("./data/image/2.png");
	tile4 = IMG_Load("./data/image/4.png");
	tile8 = IMG_Load("./data/image/8.png");
	tile16 = IMG_Load("./data/image/16.png");
	tile32 = IMG_Load("./data/image/32.png");
	tile64 = IMG_Load("./data/image/64.png");
	tile128 = IMG_Load("./data/image/128.png");
	tile256 = IMG_Load("./data/image/256.png");
	tile512 = IMG_Load("./data/image/512.png");
	tile1024 = IMG_Load("./data/image/1024.png");
	tile2048 = IMG_Load("./data/image/2048.png");
	tile0 = IMG_Load("./data/image/0.png");
	grow = Mix_LoadWAV("./data/sounds/grox.ogg");
	move = Mix_LoadWAV("./data/sounds/move.ogg");
}

void Grid::reset_tmp()
{
	for (int i = 0; i < n; i++)
		for (int j = 0; j < n; j++)
			tmp[i][j] = 0;
}

void Grid::reset_buff()
{
	for (int i = 0; i < n; i++)
		for (int j = 0; j < n; j++)
			buff[i][j] = 0;
}

void Grid::set_tmp()
{
	for (int i = 0; i < n; i++)
		for (int j = 0; j < n; j++)
			tmp[i][j] = tab[i][j];
}

void Grid::set_buff()
{
	for (int i = 0; i < n; i++)
		for (int j = 0; j < n; j++)
			buff[i][j] = tab[i][j];
}

void Grid::reset_tab()
{
	for (int i = 0; i < n; i++)
		for (int j = 0; j < n; j++)
			tab[i][j] = 0;
}

void Grid::generate()
{
	int a, b;
	do
		a = rand() % 5;
	while (a % 2 != 0 || a == 0);
	do
		b = rand() % 5;
	while (b % 2 != 0 || b == 0);
	tab[rand() % 4][rand() % 4] = a;
	tab[rand() % 4][rand() % 4] = b;
	show();
}

void Grid::show()
{
	SDL_Rect pos;
	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < n; j++)
		{
			pos.x = j * BLOC;
			pos.y = i * BLOC;
			if (tab[i][j] == 0)
				SDL_BlitSurface(tile0, NULL, ecran, &pos);
			if (tab[i][j] == 2)
				SDL_BlitSurface(tile2, NULL, ecran, &pos);
			if (tab[i][j] == 4)
				SDL_BlitSurface(tile4, NULL, ecran, &pos);
			if (tab[i][j] == 8)
				SDL_BlitSurface(tile8, NULL, ecran, &pos);
			if (tab[i][j] == 16)
				SDL_BlitSurface(tile16, NULL, ecran, &pos);
			if (tab[i][j] == 32)
				SDL_BlitSurface(tile32, NULL, ecran, &pos);
			if (tab[i][j] == 64)
				SDL_BlitSurface(tile64, NULL, ecran, &pos);
			if (tab[i][j] == 128)
				SDL_BlitSurface(tile128, NULL, ecran, &pos);
			if (tab[i][j] == 256)
				SDL_BlitSurface(tile256, NULL, ecran, &pos);
			if (tab[i][j] == 512)
				SDL_BlitSurface(tile512, NULL, ecran, &pos);
			if (tab[i][j] == 1024)
				SDL_BlitSurface(tile1024, NULL, ecran, &pos);
			if (tab[i][j] == 2048)
				SDL_BlitSurface(tile2048, NULL, ecran, &pos);
		}
	}
}


void Grid::update()
{
	SDL_Event event;
	while (!check_end() && !check_gameover())
	{
		set_tmp();
		SDL_PollEvent(&event);
		switch (event.type)
		{
		case SDL_KEYDOWN:
			{
				switch (event.key.keysym.sym)
				{					
				case SDLK_LEFT:
					gauche();
					break;
				case SDLK_RIGHT:
					droite();
					break;
				case SDLK_UP:
					haut();
					break;
				case SDLK_DOWN:
					bas();
					break;
				}				
			}
		}
		if (compare_tab(tab, tmp)&&!check_gameover())
		{
			Mix_PlayChannel(-1,move,0);
			add_number();
		}
		show();
		SDL_Flip(ecran);
	}
}

bool Grid::check_gameover()
{
	set_buff();
	buff_haut(buff);
	if (!compare_tab(tab, buff))
	{
		buff_bas(buff);
		if (!compare_tab(tab, buff))
		{
			buff_gauche(buff);
			if (!compare_tab(tab, buff))
			{
				buff_droite(buff);
				if (!compare_tab(tab, buff))
					return true;
			}
		}
	}
	reset_buff();
	return false;
}

bool Grid::check_end()
{
	for (int i = 0; i < n; i++)
		for (int j = 0; j < n; j++)
			if (tab[i][j] == 2048)
				return true;
	return false;
}

void Grid::add_number()
{
	int compteur = 0;
	for (int i = 0; i < n; i++)
		for (int j = 0; j < n; j++)
			if (tab[i][j] == 0)
				compteur++;
	if (compteur>0)
	{
	int p1, p2, a;
	do
	{
		p1 = rand() % 4;
		p2 = rand() % 4;
	}
	while (tab[p1][p2] != 0);
	tab[p1][p2] = 2;
	}
}

void Grid::transpose()
{
	reset_tmp();
	for (int i = 0; i < n; i++)
		for (int j = 0; j < n; j++)
			tmp[i][j] = tab[j][i];
	for (int i = 0; i < n; i++)
		for (int j = 0; j < n; j++)
			tab[i][j] = tmp[i][j];
	reset_tmp();
}

void Grid::haut()
{
	int k;
	SDL_Rect pos;
	SDL_Surface *tile;
	for (int j = 0; j < n; j++)
		for (int i = 0; i < n; i++)
		{
			if (tab[i][j] != 0)
			{
				k = i;
				while (k > 0)
				{
					if (!tab[k - 1][j])
						draw_up(k, j);
					k--;
				}
			}
		}
	for (int j = 0; j < n; j++)
	{
		int i = 0;
		if (test(tab[i][j], tab[i + 1][j]) && tab[i + 1][j] != 0)
		{
			draw_up(i + 1, j);
			if (test(tab[i + 2][j], tab[i + 3][j]) && tab[i + 3][j] != 0)
			{
				draw_up(i + 2, j);
				draw_up(i + 3, j);
				draw_up(i + 2, j);
			}
		}
		else
		{
			if (test(tab[i + 1][j], tab[i + 2][j]) && tab[i + 2][j] != 0)
				draw_up(i + 2, j);
			else
			{
				if (test(tab[i + 2][j], tab[i + 3][j]) && tab[i + 3][j] != 0)
					draw_up(i + 3, j);
			}
		}
	}
	for (int j = 0; j < n; j++)
		for (int i = 0; i < n; i++)
		{
			if (tab[i][j] != 0)
			{
				k = i;
				while (k > 0)
				{
					if (!tab[k - 1][j])
						draw_up(k, j);
					k--;
				}
			}
		}
}

void Grid::bas()
{
	int k = 0;
	SDL_Rect pos;
	SDL_Surface *tile;
	for (int j = 0; j < n; j++)
		for (int i = n - 1; i >= 0; i--)
		{
			if (tab[i][j] != 0)
			{
				k = i;
				while (k < n - 1)
				{
					if (!tab[k + 1][j])
						draw_down(k, j);
					k++;
				}
			}
		}
	for (int j = 0; j < n; j++)
	{
		int i = n - 1;
		if (test(tab[i][j], tab[i - 1][j]) && tab[i - 1][j] != 0)
		{
			draw_down(i - 1, j);
			if (test(tab[i - 2][j], tab[i - 3][j]) && tab[i - 3][j] != 0)
			{
				draw_down(i - 2, j);
				draw_down(i - 3, j);
				draw_down(i - 2, j);
			}
		}
		else
		{
			if (test(tab[i - 1][j], tab[i - 2][j]) && tab[i - 2][j] != 0)
				draw_down(i - 2, j);
			else if (test(tab[i - 2][j], tab[i - 3][j]) && tab[i - 3][j] != 0)
				draw_down(i - 3, j);
		}
	}
	for (int j = 0; j < n; j++)
		for (int i = n - 1; i >= 0; i--)
		{
			if (tab[i][j] != 0)
			{
				k = i;
				while (k < n - 1)
				{
					if (!tab[k + 1][j])
						draw_down(k, j);
					k++;
				}
			}
		}
}

void Grid::gauche()
{
	int k;
	SDL_Rect pos;
	SDL_Surface *tile;
	for (int j = 0; j < n; j++)
		for (int i = 0; i < n; i++)
		{
			if (tab[i][j] != 0)
			{
				k = j;
				while (k > 0)
				{
					if (!tab[i][k - 1])
						draw_left(i, k);
					k--;
				}
			}
		}
	for (int i = 0; i < n; i++)
	{
		int j = 0;
		if (test(tab[i][j], tab[i][j + 1]) && tab[i][j + 1] != 0)
		{
			draw_left(i, j + 1);
			if (test(tab[i][j + 2], tab[i][j + 3]) && tab[i][j + 3] != 0)
			{
				draw_left(i, j + 2);
				draw_left(i, j + 3);
				draw_left(i, j + 2);
			}
		}
		else
		{
			if (test(tab[i][j + 1], tab[i][j + 2]) && tab[i][j + 2] != 0)
				draw_left(i, j + 2);
			else if (test(tab[i][j + 2], tab[i][j + 3]) && tab[i][j + 3] != 0)
				draw_left(i, j + 3);
		}
	}
	for (int j = 0; j < n; j++)
		for (int i = 0; i < n; i++)
		{
			if (tab[i][j] != 0)
			{
				k = j;
				while (k > 0)
				{
					if (!tab[i][k - 1])
						draw_left(i, k);
					k--;
				}
			}
		}
}

void Grid::droite()
{
	int k = 0;
	SDL_Rect pos;
	SDL_Surface *tile;
	for (int j = 0; j < n; j++)
		for (int i = n - 1; i >= 0; i--)
		{
			if (tab[i][j] != 0)
			{
				k = j;
				while (k < n - 1)
				{
					if (!tab[i][k + 1])
						draw_right(i, k);
					k++;
				}
			}
		}
	for (int i = 0; i < n; i++)
	{
		int j = n - 1;
		if (test(tab[i][j], tab[i][j - 1]) && tab[i][j - 1] != 0)
		{
			draw_right(i, j - 1);
			if (test(tab[i][j - 2], tab[i][j - 3]) && tab[i][j - 3] != 0)
			{
				draw_right(i, j - 2);
				draw_right(i, j - 3);
				draw_right(i, j - 2);
			}
		}
		else
		{
			if (test(tab[i][j - 1], tab[i][j - 2]) && tab[i][j - 2] != 0)
				draw_right(i, j - 2);
			else if (test(tab[i][j - 2], tab[i][j - 3]) && tab[i][j - 3] != 0)
				draw_right(i, j - 3);
		}
	}
	for (int j = 0; j < n; j++)
		for (int i = n - 1; i >= 0; i--)
		{
			if (tab[i][j] != 0)
			{
				k = j;
				while (k < n - 1)
				{
					if (!tab[i][k + 1])
						draw_right(i, k);
					k++;
				}
			}
		}
}

void Grid::draw_up(int i, int j)
{
	SDL_Rect pos;
	SDL_Surface *tile;
	pos.x = j * BLOC;
	pos.y = i * BLOC;
	tile = set(i, j);
	int buff = tab[i][j];
	tab[i][j] = 0;
	while (pos.y >= (i - 1) * BLOC)
	{
		show();
		SDL_BlitSurface(tile, NULL, ecran, &pos);
		SDL_Delay(5);
		SDL_Flip(ecran);
		pos.y -= 3;
	}
	tab[i - 1][j] += buff;
		Mix_PlayChannel(-1,grow,0);
	SDL_Flip(ecran);
}

void Grid::draw_down(int i, int j)
{
	SDL_Rect pos;
	SDL_Surface *tile;
	pos.x = j * BLOC;
	pos.y = i * BLOC;
	tile = set(i, j);
	int buff = tab[i][j];
	tab[i][j] = 0;
	while (pos.y <= (i + 1) * BLOC)
	{
		show();
		SDL_BlitSurface(tile, NULL, ecran, &pos);
		SDL_Delay(5);
		SDL_Flip(ecran);
		pos.y += 3;
	}
	tab[i + 1][j] += buff;
		Mix_PlayChannel(-1,grow,0);
	SDL_Flip(ecran);
}

void Grid::draw_left(int i, int j)
{
	SDL_Rect pos;
	SDL_Surface *tile;
	pos.x = j * BLOC;
	pos.y = i * BLOC;
	tile = set(i, j);
	int buff = tab[i][j];
	tab[i][j] = 0;
	while (pos.x >= (j - 1) * BLOC)
	{
		show();
		SDL_BlitSurface(tile, NULL, ecran, &pos);
		SDL_Delay(5);
		SDL_Flip(ecran);
		pos.x -= 3;
	}
	tab[i][j - 1] += buff;
		Mix_PlayChannel(-1,grow,0);
	SDL_Flip(ecran);
}

void Grid::draw_right(int i, int j)
{
	SDL_Rect pos;
	SDL_Surface *tile;
	pos.x = j * BLOC;
	pos.y = i * BLOC;
	tile = set(i, j);
	int buff = tab[i][j];
	tab[i][j] = 0;
	while (pos.x <= (j + 1) * BLOC)
	{
		show();
		SDL_BlitSurface(tile, NULL, ecran, &pos);
		SDL_Delay(5);
		SDL_Flip(ecran);
		pos.x += 3;
	}
	tab[i][j + 1] += buff;
		Mix_PlayChannel(-1,grow,0);
	SDL_Flip(ecran);
}

SDL_Surface *Grid::set(int i, int j)
{
	SDL_Surface *tile;
	if (tab[i][j] == 0)
		tile = IMG_Load("./data/image/0.png");
	if (tab[i][j] == 2)
		tile = IMG_Load("./data/image/2.png");
	if (tab[i][j] == 4)
		tile = IMG_Load("./data/image/4.png");
	if (tab[i][j] == 8)
		tile = IMG_Load("./data/image/8.png");
	if (tab[i][j] == 16)
		tile = IMG_Load("./data/image/16.png");
	if (tab[i][j] == 32)
		tile = IMG_Load("./data/image/32.png");
	if (tab[i][j] == 64)
		tile = IMG_Load("./data/image/64.png");
	if (tab[i][j] == 128)
		tile = IMG_Load("./data/image/128.png");
	if (tab[i][j] == 256)
		tile = IMG_Load("./data/image/256.png");
	if (tab[i][j] == 512)
		tile = IMG_Load("./data/image/512.png");
	if (tab[i][j] == 1024)
		tile = IMG_Load("./data/image/1024.png");
	if (tab[i][j] == 2048)
		tile = IMG_Load("./data/image/2048.png");
	return tile;
}
