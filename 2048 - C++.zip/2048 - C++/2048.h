#ifndef _2048_H
#define _2048_H

class _2048_
{
    private:
        SDL_Surface *ecran;
    public:
        _2048_();
        void begin();
        void run();
        void end();
};

#endif // 2048_H
