#include "fonctions.h"

using namespace std;

bool test(int a, int b)
{
	if (a == b && a != 0)
		return true;
	return false;
}

bool compare_tab(vector < vector < int > >tab, vector < vector < int > >tab1)
{
	for (int i = 0; i < n; i++)
		for (int j = 0; j < n; j++)
			if (tab[i][j] != tab1[i][j])
				return true;
	return false;
}

void echange3(vector < vector < int > >&tab)
{
	vector < vector < int > >tmp;
	for (int i = 0; i < n; i++)
		tmp.push_back(vector < int >(n));
	for (int j = 0; j < n; j++)
	{
		int m = 0, p = 3;
		while (m < n && p >= 0)
		{
			tmp[p][j] = tab[m][j];
			m++;
			p--;
		}
	}
	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < n; j++)
		{
			tab[i][j] = tmp[i][j];
		}
	}
}


void echange2(vector < vector < int > >&tab)
{
	vector < vector < int > >tmp;
	for (int i = 0; i < n; i++)
		tmp.push_back(vector < int >(n));
	for (int j = 0; j < n; j++)
	{
		int m = 0, p = 3;
		while (m < n && p >= 0)
		{
			tmp[j][m] = tab[j][p];
			m++;
			p--;
		}
	}
	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < n; j++)
		{
			tab[i][j] = tmp[i][j];
		}
	}
}

void echange(vector < vector < int > >&tab)
{
	vector < vector < int > >tmp;
	for (int i = 0; i < n; i++)
		tmp.push_back(vector < int >(n));
	for (int j = 0; j < n;j++)
	{
		int m = 0, p = 3;
		while (m < n && p >= 0)
		{
			tmp[m][j] = tab[p][j];
			m++;
			p--;
		}
	}
	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < n; j++)
		{
			tab[i][j] = tmp[i][j];
		}
	}
}

void transpose(vector < vector < int > >&tab)
{
	vector < vector < int > >tmp;
	for (int i = 0; i < n; i++)
		tmp.push_back(vector < int >(n));
	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < n; j++)
		{
			tmp[i][j] = tab[j][i];
		}
	}
	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < n; j++)
		{
			tab[i][j] = tmp[i][j];
		}
	}
}

void buff_haut(vector < vector < int > >&tab)
{
	int i = 0, k;
	for (int l = 0; l < n; l++)
	{
		for (int i = 0; i < n; i++)
		{
			k = 0;
			if (tab[l][i])
			{
				k = l;
				while (k > 0)
				{
					if (!tab[k - 1][i])
					{
						tab[k - 1][i] = tab[k][i];
						tab[k][i] = 0;
					}
					k--;
				}
			}
		}
	}
	for (int j = 0; j < n; j++)
	{
		i = 0;
		if (test(tab[i][j], tab[i + 1][j]))
		{
			tab[i][j] += tab[i + 1][j];
			if (test(tab[i + 2][j], tab[i + 3][j]))
			{
				tab[i + 1][j] = tab[i + 2][j] + tab[i + 3][j];
				tab[i + 2][j] = 0;
				tab[i + 3][j] = 0;
			}
			else
			{
				tab[i + 1][j] = tab[i + 2][j];
				tab[i + 2][j] = tab[i + 3][j];
				tab[i + 3][j] = 0;
			}
		}
		else
		{
			if (test(tab[i + 1][j], tab[i + 2][j]))
			{
				tab[i + 1][j] += tab[i + 2][j];
				tab[i + 2][j] = tab[i + 3][j];
				tab[i + 3][j] = 0;
			}
			else
			{
				if (test(tab[i + 2][j], tab[i + 3][j]))
				{
					tab[i + 2][j] += tab[i + 3][j];
					tab[i + 3][j] = 0;
				}
			}
		}
	}
}

void buff_bas(vector < vector < int > >&tab)
{
	int i = 0, k;
	echange3(tab);
	for (int l = 0; l < n; l++)
	{
		for (int i = 0; i < n; i++)
		{
			k = 0;
			if (tab[l][i])
			{
				k = l;
				while (k > 0)
				{
					if (!tab[k - 1][i])
					{
						tab[k - 1][i] = tab[k][i];
						tab[k][i] = 0;
					}
					k--;
				}
			}
		}
	}
	echange3(tab);
	for (int j = 0; j < n; j++)
	{
		i = 3;
		if (test(tab[i][j], tab[i - 1][j]))
		{
			tab[i][j] += tab[i - 1][j];
			if (test(tab[i - 2][j], tab[i - 3][j]))
			{
				tab[i - 1][j] = tab[i - 2][j] + tab[i - 3][j];
				tab[i - 2][j] = 0;
				tab[i - 3][j] = 0;
			}
			else
			{
				tab[i - 1][j] = tab[i - 2][j];
				tab[i - 2][j] = tab[i - 3][j];
				tab[i - 3][j] = 0;
			}
		}
		else
		{
			if (test(tab[i - 1][j], tab[i - 2][j]))
			{
				tab[i - 1][j] += tab[i - 2][j];
				tab[i - 2][j] = tab[i - 3][j];
				tab[i - 3][j] = 0;
			}
			else
			{
				if (test(tab[i - 2][j], tab[i - 3][j]))
				{
					tab[i - 2][j] += tab[i - 3][j];
					tab[i - 3][j] = 0;
				}
			}
		}
	}
}

void buff_gauche(vector < vector < int > >&tab)
{
	int j = 0, k;
	echange(tab);
	transpose(tab);
	for (int l = 0; l < n; l++)
	{
		for (int i = 0; i < n; i++)
		{
			k = 0;
			if (tab[l][i])
			{
				k = l;
				while (k > 0)
				{
					if (!tab[k - 1][i])
					{
						tab[k - 1][i] = tab[k][i];
						tab[k][i] = 0;
					}
					k--;
				}
			}
		}
	}
	transpose(tab);
	echange(tab);
	for (int i = 0; i < n; i++)
	{
		j = 0;
		if (test(tab[i][j], tab[i][j + 1]))
		{
			tab[i][j] += tab[i][j + 1];
			if (test(tab[i][j + 2], tab[i][j + 3]))
			{
				tab[i][j + 1] = tab[i][j + 2] + tab[i][j + 3];
				tab[i][j + 2] = 0;
				tab[i][j + 3] = 0;
			}
			else
			{
				tab[i][j + 1] = tab[i][j + 2];
				tab[i][j + 2] = tab[i][j + 3];
				tab[i][j + 3] = 0;
			}
		}
		else
		{
			if (test(tab[i][j + 1], tab[i][j + 2]))
			{
				tab[i][j + 1] += tab[i][j + 2];
				tab[i][j + 2] = tab[i][j + 3];
				tab[i][j + 3] = 0;
			}
			else
			{
				if (test(tab[i][j + 2], tab[i][j + 3]))
				{
					tab[i][j + 2] += tab[i][j + 3];
					tab[i][j + 3] = 0;
				}
			}
		}
	}
}


void buff_droite(vector < vector < int > >&tab)
{
	int j = 0, k;
	echange2(tab);
	transpose(tab);
	for (int l = 0; l < n; l++)
	{
		for (int i = 0; i < n; i++)
		{
			k = 0;
			if (tab[l][i])
			{
				k = l;
				while (k > 0)
				{
					if (!tab[k - 1][i])
					{
						tab[k - 1][i] = tab[k][i];
						tab[k][i] = 0;
					}
					k--;
				}
			}
		}
	}
	transpose(tab);
	echange2(tab);
	for (int i = 0; i < n; i++)
	{
		j = 3;
		if (test(tab[i][j], tab[i][j - 1]))
		{
			tab[i][j] += tab[i][j - 1];
			if (test(tab[i][j - 2], tab[i][j - 3]))
			{
				tab[i][j - 1] = tab[i][j - 2] + tab[i][j - 3];
				tab[i][j - 2] = 0;
				tab[i][j - 3] = 0;
			}
			else
			{
				tab[i][j - 1] = tab[i][j - 2];
				tab[i][j - 2] = tab[i][j - 3];
				tab[i][j - 3] = 0;
			}
		}
		else
		{
			if (test(tab[i][j - 1], tab[i][j - 2]))
			{
				tab[i][j - 1] += tab[i][j - 2];
				tab[i][j - 2] = tab[i][j - 3];
				tab[i][j - 3] = 0;
			}
			else
			{
				if (test(tab[i][j - 2], tab[i][j - 3]))
				{
					tab[i][j - 2] += tab[i][j - 3];
					tab[i][j - 3] = 0;
				}
			}
		}
	}
}
