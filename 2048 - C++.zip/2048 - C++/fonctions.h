#ifndef FONCTIONS_H
#define FONCTIONS_H

#include <vector>
#include "defs.h"

using namespace std;

bool test(int a,int b);
bool compare_tab(vector < vector <int> > tab,vector < vector <int> > tab1);
void echange (vector < vector <int> > &tab);
void echange2(vector < vector <int> > &tab);
void echange3(vector < vector <int> > &tab);
void buff_haut(vector < vector <int> > &tab);
void buff_bas(vector < vector <int> > &tab);
void buff_gauche(vector < vector <int> > &tab);
void buff_droite(vector < vector <int> > &tab);
void transpose(vector < vector <int> > &tab);

#endif